
"""
ZYREX SHOP API Client
Python 3.9+
Dependency: requests

Security:
- API key stored in environment variables.
- No automatic retry for purchases.
- Idempotency-Key required for purchase requests.
"""

import json
import os
import sys
import requests


class ZyrexAPI:
    def __init__(self, base_url=None, api_key=None):
        self.base_url = (
            base_url or os.getenv("ZYREX_API_URL", "https://www.zyrexotp.com/api/v1")
        ).rstrip("/")

        self.api_key = api_key or os.getenv("ZYREX_API_KEY", "")

        if not self.base_url.startswith(("https://", "http://")):
            raise ValueError("Invalid API URL.")

        if not self.api_key:
            raise ValueError(
                "API Key belum diatur. Gunakan environment variable ZYREX_API_KEY."
            )

        self.session = requests.Session()

    def request(
        self,
        method,
        path,
        payload=None,
        idempotency_key=None,
        params=None
    ):
        if (
            not isinstance(path, str)
            or not path.startswith("/")
            or path.startswith("//")
            or "://" in path
        ):
            raise ValueError(
                "Gunakan relative path, contoh /balance atau /order."
            )

        method = method.upper()

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json"
        }

        if method == "POST" and path in ("/order", "/smm/order"):
            if (
                not isinstance(idempotency_key, str)
                or not 16 <= len(idempotency_key) <= 128
            ):
                raise ValueError(
                    "Order memerlukan Idempotency-Key "
                    "16-128 karakter."
                )

            headers["Idempotency-Key"] = idempotency_key

        try:
            response = self.session.request(
                method=method,
                url=self.base_url + path,
                params=params,
                json=payload,
                headers=headers,
                timeout=(5, 25),
                allow_redirects=False
            )

        except requests.RequestException:
            raise RuntimeError(
                "Koneksi gagal atau timeout. "
                "Status transaksi POST mungkin belum pasti. "
                "Jangan mengulangi transaksi dengan key berbeda."
            ) from None

        try:
            body = response.json()

        except ValueError:
            body = {
                "success": False,
                "message": "Respons bukan JSON."
            }

        return {
            "http_status": response.status_code,
            "body": body
        }


if __name__ == "__main__":

    method = sys.argv[1] if len(sys.argv) > 1 else "GET"
    path = sys.argv[2] if len(sys.argv) > 2 else "/balance"

    payload = None

    if len(sys.argv) > 3:
        with open(sys.argv[3], encoding="utf-8") as source:
            payload = json.load(source)

        if not isinstance(payload, dict):
            raise ValueError("Payload harus berupa objek JSON.")

    key = sys.argv[4] if len(sys.argv) > 4 else None

    try:
        api = ZyrexAPI()

        result = api.request(
            method=method,
            path=path,
            payload=payload,
            idempotency_key=key
        )

        print(
            json.dumps(
                result,
                indent=2,
                ensure_ascii=False
            )
        )

    except (ValueError, RuntimeError) as error:
        sys.exit(str(error))
