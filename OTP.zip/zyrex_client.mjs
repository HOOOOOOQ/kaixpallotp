/** ZYREX SHOP API client. Node.js 18+, built-in fetch. No automatic purchase retries. */
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
export class ZyrexAPI {
  constructor(baseURL=process.env.ZYREX_API_URL,apiKey=process.env.ZYREX_API_KEY){
    if(!baseURL||!/^https?:\/\//.test(baseURL)||!apiKey)throw Error('Isi ZYREX_API_URL (hingga /api/v1) dan ZYREX_API_KEY di backend.');
    this.baseURL=baseURL.replace(/\/$/,'');this.apiKey=apiKey;
  }
  async request(method,path,payload=null,idempotencyKey=null){
    if(!path.startsWith('/')||path.startsWith('//')||path.includes('://'))throw Error('Gunakan path relatif seperti /balance.');
    method=method.toUpperCase();const headers={Authorization:`Bearer ${this.apiKey}`,Accept:'application/json'};
    if(method==='POST'&&['/order','/smm/order'].includes(path)){
      if(!idempotencyKey||idempotencyKey.length<16||idempotencyKey.length>128)throw Error('Simpan Idempotency-Key 16–128 karakter untuk satu order dan seluruh retry-nya.');
      headers['Idempotency-Key']=idempotencyKey;
    }
    if(payload!==null)headers['Content-Type']='application/json';
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),25000);
    try{
      const response=await fetch(this.baseURL+path,{method,headers,body:payload===null?undefined:JSON.stringify(payload),signal:controller.signal,redirect:'error'});
      let body;
      try{body=await response.json();}catch(error){if(error.name==='AbortError')throw error;body={success:false,message:'Respons bukan JSON; periksa status HTTP.'};}
      return {http_status:response.status,body};
    }catch{throw Error('Koneksi gagal/timeout. Hasil POST mungkin belum pasti; jangan ulang dengan key berbeda.');}
    finally{clearTimeout(timer);}
  }
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
  try{const method=process.argv[2]||'GET',path=process.argv[3]||'/balance';const payload=process.argv[4]?JSON.parse(readFileSync(process.argv[4],'utf8')):null;
    if(payload!==null&&(typeof payload!=='object'||Array.isArray(payload)))throw Error('Payload harus objek JSON.');
    console.log(JSON.stringify(await new ZyrexAPI().request(method,path,payload,process.argv[5]),null,2));
  }catch(error){console.error(error.message);process.exitCode=1;}
}
