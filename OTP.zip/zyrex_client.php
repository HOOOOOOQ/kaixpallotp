
<?php
/**
 * ZYREX SHOP API CLIENT
 * PHP 8+
 * Required extension: curl
 * No automatic purchase retries.
 */

final class ZyrexAPI
{
    private string $baseUrl;
    private string $apiKey;

    public function __construct(
        ?string $baseUrl = null,
        ?string $apiKey = null
    ) {
        $this->baseUrl = rtrim(
            $baseUrl ?? (getenv('ZYREX_API_URL') ?: 'https://www.zyrexotp.com/api/v1'),
            '/'
        );

        $this->apiKey = $apiKey ?? (getenv('ZYREX_API_KEY') ?: '');

        if (!preg_match('#^https?://#i', $this->baseUrl)) {
            throw new RuntimeException('URL API tidak valid.');
        }

        if ($this->apiKey === '') {
            throw new RuntimeException(
                'ZYREX_API_KEY belum diatur.'
            );
        }

        if (!extension_loaded('curl')) {
            throw new RuntimeException('PHP extension cURL belum aktif.');
        }
    }

    public function request(
        string $method,
        string $path,
        ?array $payload = null,
        ?string $idempotencyKey = null,
        ?array $params = null
    ): array {

        if (
            !str_starts_with($path, '/') ||
            str_starts_with($path, '//') ||
            str_contains($path, '://')
        ) {
            throw new InvalidArgumentException(
                'Gunakan relative path seperti /balance.'
            );
        }

        $method = strtoupper($method);

        $url = $this->baseUrl . $path;

        if ($params !== null && !empty($params)) {
            $url .= '?' . http_build_query($params);
        }

        $headers = [
            'Authorization: Bearer ' . $this->apiKey,
            'Accept: application/json'
        ];

        if (
            $method === 'POST' &&
            in_array($path, ['/order', '/smm/order'], true)
        ) {
            if (
                $idempotencyKey === null ||
                strlen($idempotencyKey) < 16 ||
                strlen($idempotencyKey) > 128
            ) {
                throw new InvalidArgumentException(
                    'Order memerlukan Idempotency-Key 16-128 karakter.'
                );
            }

            $headers[] = 'Idempotency-Key: ' . $idempotencyKey;
        }

        $handle = curl_init($url);

        if ($handle === false) {
            throw new RuntimeException('Gagal menginisialisasi cURL.');
        }

        $options = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 25,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2
        ];

        if ($payload !== null) {
            $headers[] = 'Content-Type: application/json';

            $options[CURLOPT_HTTPHEADER] = $headers;

            $options[CURLOPT_POSTFIELDS] = json_encode(
                $payload,
                JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE
            );
        }

        if ($method === 'GET' && $payload !== null) {
            curl_close($handle);
            throw new InvalidArgumentException(
                'GET tidak boleh menggunakan payload JSON.'
            );
        }

        curl_setopt_array($handle, $options);

        $raw = curl_exec($handle);
        $curlError = curl_error($handle);
        $status = curl_getinfo($handle, CURLINFO_RESPONSE_CODE);

        curl_close($handle);

        if ($raw === false) {
            throw new RuntimeException(
                'Koneksi gagal: ' . $curlError .
                '. Status transaksi POST mungkin belum pasti. Jangan mengulang dengan key berbeda.'
            );
        }

        $body = json_decode($raw, true);

        if (!is_array($body)) {
            $body = [
                'success' => false,
                'message' => 'Respons bukan JSON.',
                'raw_response' => $raw
            ];
        }

        return [
            'http_status' => $status,
            'body' => $body
        ];
    }
}


/**
 * CLI EXECUTION
 */

if (
    PHP_SAPI === 'cli' &&
    isset($_SERVER['SCRIPT_FILENAME']) &&
    realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__
) {
    try {
        $method = $argv[1] ?? 'GET';
        $path = $argv[2] ?? '/balance';

        $payload = null;

        if (isset($argv[3])) {
            $content = file_get_contents($argv[3]);

            if ($content === false) {
                throw new RuntimeException('Gagal membaca payload JSON.');
            }

            $payload = json_decode(
                $content,
                true,
                512,
                JSON_THROW_ON_ERROR
            );

            if (!is_array($payload)) {
                throw new InvalidArgumentException(
                    'Payload harus berupa objek atau array JSON.'
                );
            }
        }

        $key = $argv[4] ?? null;

        $api = new ZyrexAPI();

        $result = $api->request(
            $method,
            $path,
            $payload,
            $key
        );

        echo json_encode(
            $result,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
        ) . PHP_EOL;

    } catch (Throwable $error) {
        fwrite(
            STDERR,
            '[ERROR] ' . $error->getMessage() . PHP_EOL
        );

        exit(1);
    }
}
